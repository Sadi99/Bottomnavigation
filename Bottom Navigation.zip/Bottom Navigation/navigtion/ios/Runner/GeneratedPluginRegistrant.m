//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<flashy_tab_bar/FlashyTabBarPlugin.h>)
#import <flashy_tab_bar/FlashyTabBarPlugin.h>
#else
@import flashy_tab_bar;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [FlashyTabBarPlugin registerWithRegistrar:[registry registrarForPlugin:@"FlashyTabBarPlugin"]];
}

@end
