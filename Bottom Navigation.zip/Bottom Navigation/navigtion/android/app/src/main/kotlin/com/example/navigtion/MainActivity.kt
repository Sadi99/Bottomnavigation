package com.example.navigtion

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
