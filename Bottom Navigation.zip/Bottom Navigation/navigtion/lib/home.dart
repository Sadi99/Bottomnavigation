// ignore_for_file: prefer_const_constructors, import_of_legacy_library_into_null_safe

import 'package:flashy_tab_bar/flashy_tab_bar.dart';
import 'package:flutter/material.dart';

class Homepage extends StatefulWidget {
  const Homepage({Key? key}) : super(key: key);

  @override
  _HomepageState createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  int cindex = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: FlashyTabBar(
        items: [
          FlashyTabBarItem(icon: Icon(Icons.event), title: Text("Event")),
          FlashyTabBarItem(icon: Icon(Icons.search), title: Text("Search")),
          FlashyTabBarItem(
              icon: Icon(Icons.highlight), title: Text("Highlight")),
          FlashyTabBarItem(icon: Icon(Icons.settings), title: Text("Settings")),
        ],
      ),
    );
  }
}
